# Alex Chen Portfolio - Full-Stack Application

## Overview

This is a modern full-stack web application built as a software engineer portfolio for Alex Chen. The application showcases a complete portfolio website with a responsive design, built using React for the frontend and Express.js for the backend, with PostgreSQL as the database solution. The website features dynamic content management with database integration for projects, skills, and contact messages, along with a beautiful glass morphism design and smooth animations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack architecture with clear separation between client and server code:

- **Frontend**: React-based single-page application with TypeScript
- **Backend**: Express.js REST API server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Build System**: Vite for frontend bundling and development
- **Deployment**: Node.js production build with static file serving

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Router**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with custom design tokens
- **UI Components**: shadcn/ui (Radix UI primitives)
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API design with `/api` prefix
- **Middleware**: JSON parsing, URL encoding, request logging
- **Error Handling**: Centralized error middleware

### Database Layer
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with schema-first approach
- **Migrations**: Drizzle Kit for database migrations
- **Validation**: Zod schemas for type-safe data validation

### Component Structure
- **Pages**: Home (portfolio showcase), 404 error page
- **Sections**: Hero, About (with dynamic skills), Projects (with database integration), Contact (with form submission), Footer
- **UI Components**: Complete shadcn/ui component library with glass morphism effects
- **Shared Schema**: Type definitions shared between client and server
- **Database Models**: Projects, Skills, Contact Messages, Users with proper relations

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **Server Processing**: Express routes handle requests with middleware chain
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Response Handling**: JSON responses with proper error codes
5. **State Management**: React Query caches and synchronizes server state

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Unstyled, accessible UI primitives
- **drizzle-orm**: Type-safe database toolkit
- **wouter**: Lightweight React router

### Development Tools
- **Vite**: Frontend build tool and dev server
- **TypeScript**: Static type checking
- **Tailwind CSS**: Utility-first CSS framework
- **esbuild**: Server-side bundling for production

### UI and Styling
- **shadcn/ui**: Pre-built component library
- **Lucide React**: Icon library
- **class-variance-authority**: Utility for component variants
- **clsx**: Conditional class name utility

## Deployment Strategy

### Development Mode
- Vite dev server with HMR for frontend development
- tsx for TypeScript execution in development
- Concurrent client and server development with hot reloading

### Production Build
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles Express server to `dist/index.js`
3. **Static Serving**: Express serves built frontend files
4. **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **NODE_ENV**: Development/production mode switching
- **DATABASE_URL**: PostgreSQL connection string (required)
- **PORT**: Server port configuration

### Key Architectural Decisions

1. **Monorepo Structure**: Single repository with client, server, and shared code
2. **TypeScript First**: Full type safety across frontend and backend
3. **Component-Driven UI**: Modular, reusable components with shadcn/ui
4. **Schema Sharing**: Common type definitions between client and server
5. **Modern Tooling**: Vite, esbuild, and ES modules for optimal performance
6. **Database-First**: Drizzle schema as source of truth for data models
7. **Responsive Design**: Mobile-first approach with Tailwind CSS
8. **Error Boundaries**: Comprehensive error handling and user feedback
9. **Dynamic Content**: Database-driven content management for projects and skills
10. **Glass Morphism Design**: Modern visual effects with backdrop blur and gradients
11. **Real-time Features**: Contact form with database persistence and validation

### Recent Changes (January 2025)

✓ **Complete Database Integration**: Migrated from static data to PostgreSQL with Drizzle ORM  
✓ **Projects API**: Full CRUD operations for portfolio projects with featured flag support  
✓ **Skills Management**: Dynamic skills section fetching from database with icon mapping  
✓ **Contact Form**: Database persistence for contact submissions with proper validation  
✓ **Data Seeding**: Sample data populated for showcase projects and technical skills  
✓ **Loading States**: Skeleton loaders for improved user experience during data fetching  

The application is designed to be easily deployable to platforms like Replit, Vercel, or traditional hosting providers, with environment-based configuration and production-ready build processes.