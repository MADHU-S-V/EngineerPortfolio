import { useState } from "react";
import { Mail, Linkedin, Github, Phone, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const contactMutation = useMutation({
    mutationFn: (data: typeof formData) => 
      apiRequest("/api/contact-messages", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      });
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
      
      // Invalidate contact messages cache
      queryClient.invalidateQueries({ queryKey: ["/api/contact-messages"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields before submitting.",
        variant: "destructive"
      });
      return;
    }

    contactMutation.mutate(formData);
  };

  const downloadResume = () => {
    // In a real application, this would download the actual resume file
    toast({
      title: "Download Started",
      description: "Resume download will begin shortly.",
    });
  };

  const contactItems = [
    {
      icon: Mail,
      label: "Email",
      value: "alex.chen@email.com",
      color: "text-blue-600"
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      value: "linkedin.com/in/alexchen",
      color: "text-blue-600"
    },
    {
      icon: Github,
      label: "GitHub",
      value: "github.com/alexchen",
      color: "text-blue-600"
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+1 (555) 123-4567",
      color: "text-blue-600"
    }
  ];

  return (
    <section id="contact" className="py-24 bg-gray-50 dark:bg-gray-950 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-36 h-36 bg-gradient-to-br from-blue-300/20 to-cyan-300/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-28 h-28 bg-gradient-to-br from-purple-300/20 to-pink-300/20 rounded-lg blur-2xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20 fade-in">
          <div className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-100/80 to-cyan-100/80 rounded-full text-sm font-semibold text-blue-700 backdrop-blur-sm">
            🤝 Get In Touch
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black dark:text-white mb-6">
            Let's Work <span className="text-blue-500">Together</span>
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
            I'm always interested in new opportunities and exciting projects. Whether you're a startup looking to build your MVP or an established company seeking to enhance your digital presence, let's connect.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          <div className="fade-in text-center lg:text-left flex flex-col">
            <h3 className="text-2xl font-semibold text-black dark:text-white mb-8">Get In Touch</h3>
            <div className="space-y-6 flex-1">
              {contactItems.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <div 
                    key={index} 
                    className="flex items-center justify-center lg:justify-start group p-4 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all duration-200"
                  >
                    <div className="bg-blue-100 dark:bg-blue-900/30 w-16 h-16 rounded-2xl flex items-center justify-center mr-6 group-hover:shadow-lg transition-all duration-300 flex-shrink-0">
                      <IconComponent className={`h-7 w-7 ${item.color} group-hover:scale-110 transition-transform duration-300`} />
                    </div>
                    <div className="flex-1 text-center lg:text-left">
                      <p className="font-semibold text-lg text-black dark:text-white group-hover:text-blue-500 transition-colors duration-200 mb-1">{item.label}</p>
                      <p className="text-gray-600 dark:text-gray-400 text-base">{item.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-auto pt-8 text-center lg:text-left">
              <Button 
                onClick={downloadResume}
                className="group relative overflow-hidden bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 w-full lg:w-auto"
              >
                <span className="relative z-10 flex items-center justify-center">
                  <Download className="w-5 h-5 mr-3 group-hover:animate-bounce" />
                  Download Resume
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
            </div>
          </div>
          
          <div className="fade-in flex flex-col">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 lg:p-8 shadow-lg border border-gray-200 dark:border-gray-700 flex-1 flex flex-col">
              <form onSubmit={handleSubmit} className="space-y-6 flex-1 flex flex-col">
                <div>
                  <label htmlFor="name" className="block font-medium text-black dark:text-white mb-2">Name</label>
                  <Input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Your Name"
                    className="w-full px-6 py-4 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 bg-white/80 backdrop-blur-sm text-lg"
                  />
                </div>
              
                <div>
                  <label htmlFor="email" className="block font-medium text-black dark:text-white mb-2">Email</label>
                  <Input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="your.email@example.com"
                    className="w-full px-6 py-4 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 bg-white/80 backdrop-blur-sm text-lg"
                  />
                </div>
                
                <div>
                  <label htmlFor="subject" className="block font-medium text-black dark:text-white mb-2">Subject</label>
                  <Input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    placeholder="Project Opportunity"
                    className="w-full px-6 py-4 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 bg-white/80 backdrop-blur-sm text-lg"
                  />
                </div>
                
                <div className="flex-1 flex flex-col">
                  <label htmlFor="message" className="block font-medium text-black dark:text-white mb-2">Message</label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={6}
                    placeholder="Tell me about your project..."
                    className="w-full px-6 py-4 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 bg-white/80 backdrop-blur-sm text-lg resize-none flex-1"
                  />
                </div>
                
                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-full font-medium transition-all duration-200 disabled:opacity-50"
                >
                  <span className="relative z-10">
                    {contactMutation.isPending ? "Sending..." : "Send Message"}
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
