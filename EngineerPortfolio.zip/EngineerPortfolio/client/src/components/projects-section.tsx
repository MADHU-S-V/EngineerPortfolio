import { ExternalLink, Github } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Project } from "@shared/schema";

export default function ProjectsSection() {
  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects/featured"],
  });

  const tagColorClasses = {
    blue: "bg-blue-100 text-blue-700",
    green: "bg-green-100 text-green-700",
    purple: "bg-purple-100 text-purple-700",
    orange: "bg-orange-100 text-orange-700",
    red: "bg-red-100 text-red-700"
  };

  return (
    <section id="projects" className="py-24 bg-white dark:bg-black relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-32 right-20 w-40 h-40 bg-gradient-to-br from-cyan-200/20 to-blue-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-32 left-20 w-32 h-32 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-lg blur-2xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20 fade-in">
          <div className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-100/80 to-cyan-100/80 rounded-full text-sm font-semibold text-blue-700 backdrop-blur-sm">
            💻 Portfolio
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black dark:text-white mb-6">
            Featured <span className="text-blue-500">Projects</span>
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
            A showcase of my recent work spanning web applications, mobile solutions, and open-source contributions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 mb-16">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 4 }).map((_, index) => (
              <div 
                key={index} 
                className="project-card rounded-2xl overflow-hidden shadow-xl animate-pulse"
              >
                <div className="bg-slate-200 h-56 w-full"></div>
                <div className="p-8">
                  <div className="bg-slate-200 h-6 w-3/4 mb-4 rounded"></div>
                  <div className="bg-slate-200 h-4 w-full mb-2 rounded"></div>
                  <div className="bg-slate-200 h-4 w-2/3 mb-6 rounded"></div>
                  <div className="flex gap-3 mb-6">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="bg-slate-200 h-8 w-16 rounded-xl"></div>
                    ))}
                  </div>
                  <div className="flex space-x-6">
                    <div className="bg-slate-200 h-6 w-20 rounded"></div>
                    <div className="bg-slate-200 h-6 w-16 rounded"></div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            projects.map((project, index) => (
              <div 
                key={project.id} 
                className="project-card rounded-2xl overflow-hidden shadow-xl fade-in group"
                style={{animationDelay: `${index * 0.2}s`}}
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-56 object-cover transform group-hover:scale-110 transition-transform duration-500" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="p-8 relative z-10">
                  <h3 className="text-xl font-semibold text-black dark:text-white mb-3 group-hover:text-blue-500 transition-colors duration-200">
                    {project.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-3 mb-6">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className={`px-4 py-2 rounded-xl text-sm font-semibold shadow-sm hover:shadow-md transition-all duration-300 transform hover:scale-105 ${tagColorClasses[project.tagColors[tagIndex] as keyof typeof tagColorClasses]}`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex space-x-6">
                    {project.liveUrl && (
                      <a 
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group/btn text-blue-600 hover:text-blue-700 font-bold flex items-center text-lg transition-all duration-300 hover:scale-105"
                      >
                        <ExternalLink className="w-5 h-5 mr-2 group-hover/btn:translate-x-1 transition-transform duration-300" />
                        Live Demo
                      </a>
                    )}
                    {project.githubUrl && (
                      <a 
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group/btn text-slate-600 hover:text-slate-800 font-bold flex items-center text-lg transition-all duration-300 hover:scale-105"
                      >
                        <Github className="w-5 h-5 mr-2 group-hover/btn:rotate-12 transition-transform duration-300" />
                        GitHub
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="text-center fade-in">
          <button className="group relative overflow-hidden bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-10 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            <span className="relative z-10 flex items-center">
              View All Projects 
              <ExternalLink className="w-5 h-5 ml-2 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-300" />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
        </div>
      </div>
    </section>
  );
}
