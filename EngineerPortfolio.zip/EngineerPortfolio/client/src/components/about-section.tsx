import { Code, Server, Cloud, Smartphone } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Skill } from "@shared/schema";

export default function AboutSection() {
  const { data: skills = [], isLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills/featured"],
  });

  // Map icon names to actual icon components
  const iconMap = {
    Code,
    Server,
    Cloud,
    Smartphone
  };

  const colorClasses = {
    blue: "bg-blue-100 text-blue-600",
    green: "bg-green-100 text-green-600",
    purple: "bg-purple-100 text-purple-600",
    orange: "bg-orange-100 text-orange-600"
  };

  return (
    <section id="about" className="py-24 bg-gray-50 dark:bg-gray-950 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-200/30 to-cyan-200/30 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 right-10 w-24 h-24 bg-gradient-to-br from-purple-200/30 to-blue-200/30 rounded-lg blur-xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20 fade-in">
          <div className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-100/80 to-cyan-100/80 rounded-full text-sm font-semibold text-blue-700 backdrop-blur-sm">
            🚀 About Me
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black dark:text-white mb-6">
            Passionate About <span className="text-blue-500">Innovation</span>
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
            With 5+ years of experience in software development, I specialize in building scalable web applications and leading cross-functional teams to deliver exceptional products.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div className="fade-in order-2 lg:order-1">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-300"></div>
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Tech team collaboration" 
                className="relative rounded-2xl shadow-2xl w-full h-auto transform group-hover:scale-105 transition-all duration-500" 
              />
            </div>
          </div>
          
          <div className="fade-in order-1 lg:order-2">
            <h3 className="text-3xl font-black text-slate-800 mb-8 gradient-text">My Journey</h3>
            <p className="text-lg text-slate-600 mb-6 leading-relaxed">
              Started as a curious computer science student, I've evolved into a versatile engineer who thrives at the intersection of <strong className="text-slate-700">technology and user experience</strong>. I believe in writing code that not only works but tells a story of thoughtful problem-solving.
            </p>
            <p className="text-lg text-slate-600 mb-10 leading-relaxed">
              When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, or mentoring aspiring developers in the community.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <span className="bg-gradient-to-r from-blue-100 to-blue-200 text-blue-700 px-6 py-3 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                🧩 Problem Solver
              </span>
              <span className="bg-gradient-to-r from-cyan-100 to-cyan-200 text-cyan-700 px-6 py-3 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                👥 Team Leader
              </span>
              <span className="bg-gradient-to-r from-green-100 to-green-200 text-green-700 px-6 py-3 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                📚 Lifelong Learner
              </span>
            </div>
          </div>
        </div>
        
        {/* Skills Section */}
        <div className="fade-in">
          <h3 className="text-3xl font-black text-slate-800 mb-12 text-center">
            Technical <span className="gradient-text">Expertise</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {isLoading ? (
              // Loading skeleton
              Array.from({ length: 4 }).map((_, index) => (
                <div 
                  key={index} 
                  className="skill-card text-center p-8 rounded-2xl bg-white/60 backdrop-blur-sm border border-white/20 shadow-lg animate-pulse"
                >
                  <div className="w-20 h-20 rounded-2xl bg-slate-200 mx-auto mb-6"></div>
                  <div className="bg-slate-200 h-6 w-3/4 mx-auto mb-3 rounded"></div>
                  <div className="bg-slate-200 h-4 w-full mb-2 rounded"></div>
                  <div className="bg-slate-200 h-4 w-2/3 mx-auto rounded"></div>
                </div>
              ))
            ) : (
              skills.map((skill, index) => {
                const IconComponent = iconMap[skill.icon as keyof typeof iconMap] || Code;
                return (
                  <div 
                    key={skill.id} 
                    className="skill-card text-center p-8 rounded-2xl bg-white/60 backdrop-blur-sm border border-white/20 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-rotate-1"
                    style={{animationDelay: `${index * 0.1}s`}}
                  >
                    <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 ${colorClasses[skill.color as keyof typeof colorClasses]} relative overflow-hidden group`}>
                      <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent"></div>
                      <IconComponent className="h-10 w-10 relative z-10" />
                    </div>
                    <h4 className="font-bold text-slate-800 mb-3 text-lg">{skill.title}</h4>
                    <p className="text-slate-600 text-sm leading-relaxed">{skill.description}</p>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
