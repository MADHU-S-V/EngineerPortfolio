export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center relative overflow-hidden pt-20">
      {/* Background with animated gradient */}
      <div className="absolute inset-0 bg-white dark:bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/3 via-transparent to-blue-500/3 dark:from-blue-400/5 dark:via-transparent dark:to-blue-400/5"></div>
      </div>
      
      {/* Floating geometric shapes */}
      <div className="absolute top-20 left-20 w-20 h-20 bg-gradient-to-br from-blue-400/20 to-cyan-400/20 rounded-full blur-xl floating-animation" style={{animationDelay: '0s'}}></div>
      <div className="absolute top-40 right-32 w-16 h-16 bg-gradient-to-br from-purple-400/20 to-blue-400/20 rounded-lg blur-lg floating-animation" style={{animationDelay: '2s'}}></div>
      <div className="absolute bottom-32 left-1/4 w-12 h-12 bg-gradient-to-br from-cyan-400/20 to-green-400/20 rounded-full blur-lg floating-animation" style={{animationDelay: '4s'}}></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="fade-in text-center lg:text-left">
            <div className="inline-block mb-4 px-4 py-2 bg-gray-100 dark:bg-gray-900 rounded-full text-sm font-medium text-gray-700 dark:text-gray-300">
              👋 Welcome to my portfolio
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-black dark:text-white mb-6 leading-tight">
              Hi, I'm <span className="text-blue-500">Alex Chen</span>
            </h1>
            <h2 className="text-xl sm:text-2xl text-gray-600 dark:text-gray-400 mb-8 font-normal">
              Full-Stack Software Engineer
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 mb-10 leading-relaxed max-w-2xl">
              I craft elegant, scalable solutions that bridge the gap between innovative ideas and robust software systems. Passionate about clean code, user experience, and building products that make a difference.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start">
              <button 
                onClick={() => scrollToSection('projects')}
                className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-full font-medium transition-all duration-200"
              >
                View My Work
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="border border-gray-300 dark:border-gray-600 text-black dark:text-white hover:bg-gray-50 dark:hover:bg-gray-900 px-6 py-3 rounded-full font-medium transition-all duration-200"
              >
                Get In Touch
              </button>
            </div>
          </div>
          
          <div className="fade-in lg:text-right relative text-center">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl blur opacity-30 group-hover:opacity-60 transition duration-300"></div>
              <img 
                src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern software engineer workspace" 
                className="relative rounded-2xl shadow-2xl w-full h-auto transform group-hover:scale-105 transition-all duration-500" 
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
