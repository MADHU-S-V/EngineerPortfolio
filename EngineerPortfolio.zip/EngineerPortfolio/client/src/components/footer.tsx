import { Linkedin, Github, Twitter, Mail } from "lucide-react";

export default function Footer() {
  const socialLinks = [
    {
      icon: Linkedin,
      href: "#",
      label: "LinkedIn"
    },
    {
      icon: Github,
      href: "#",
      label: "GitHub"
    },
    {
      icon: Twitter,
      href: "#",
      label: "Twitter"
    },
    {
      icon: Mail,
      href: "#",
      label: "Email"
    }
  ];

  return (
    <footer className="bg-black dark:bg-black text-white py-16 relative overflow-hidden border-t border-gray-200 dark:border-gray-800">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-full blur-2xl"></div>
        <div className="absolute bottom-0 right-1/4 w-24 h-24 bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-lg blur-xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-white mb-4">Alex Chen</h3>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Building the future, one line of code at a time.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <p className="text-gray-500">&copy; 2025 Alex Chen. All rights reserved.</p>
          </div>
          
          <div className="flex space-x-8">
            {socialLinks.map((link, index) => {
              const IconComponent = link.icon;
              return (
                <a
                  key={index}
                  href={link.href}
                  className="group text-gray-500 hover:text-white transition-all duration-200"
                  aria-label={link.label}
                >
                  <div className="relative">
                    <IconComponent className="h-8 w-8 group-hover:drop-shadow-lg transition-all duration-300" />
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-full blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </footer>
  );
}
