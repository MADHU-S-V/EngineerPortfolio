import { db } from "./db";
import { projects, skills, contactMessages } from "@shared/schema";

export async function seedDatabase() {
  console.log("Seeding database...");

  try {
    // Seed projects
    const sampleProjects = [
      {
        title: "E-Commerce Platform",
        description: "A full-stack e-commerce solution built with React, Node.js, and PostgreSQL. Features include real-time inventory management, payment processing, and analytics dashboard.",
        image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["React", "Node.js", "PostgreSQL", "Stripe API"],
        tagColors: ["blue", "green", "purple", "orange"],
        liveUrl: "https://example.com",
        githubUrl: "https://github.com/example",
        featured: true
      },
      {
        title: "Task Management Mobile App",
        description: "Cross-platform mobile application for team productivity. Built with React Native, featuring offline sync, real-time collaboration, and intuitive gesture controls.",
        image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["React Native", "Firebase", "Redux", "WebSocket"],
        tagColors: ["blue", "green", "purple", "red"],
        liveUrl: "https://example.com",
        githubUrl: "https://github.com/example",
        featured: true
      },
      {
        title: "Analytics Dashboard",
        description: "Real-time business intelligence platform with interactive charts, automated reporting, and machine learning insights. Processes millions of data points daily.",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["Vue.js", "Python", "D3.js", "AWS"],
        tagColors: ["blue", "green", "purple", "orange"],
        liveUrl: "https://example.com",
        githubUrl: "https://github.com/example",
        featured: true
      },
      {
        title: "Open Source CLI Tool",
        description: "Command-line interface for developers to streamline deployment workflows. Published on npm with 10K+ downloads and active community contributions.",
        image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["TypeScript", "Node.js", "Commander.js", "Jest"],
        tagColors: ["blue", "green", "purple", "red"],
        liveUrl: "https://example.com",
        githubUrl: "https://github.com/example",
        featured: true
      }
    ];

    // Clear existing projects
    await db.delete(projects);
    
    // Insert sample projects
    await db.insert(projects).values(sampleProjects);

    // Seed skills
    const sampleSkills = [
      {
        title: "Frontend",
        description: "React, Vue.js, TypeScript, Tailwind CSS",
        icon: "Code",
        color: "blue",
        category: "development",
        featured: true
      },
      {
        title: "Backend",
        description: "Node.js, Python, PostgreSQL, MongoDB",
        icon: "Server",
        color: "green",
        category: "development",
        featured: true
      },
      {
        title: "DevOps",
        description: "AWS, Docker, Kubernetes, CI/CD",
        icon: "Cloud",
        color: "purple",
        category: "infrastructure",
        featured: true
      },
      {
        title: "Mobile",
        description: "React Native, Flutter, iOS, Android",
        icon: "Smartphone",
        color: "orange",
        category: "development",
        featured: true
      }
    ];

    // Clear existing skills
    await db.delete(skills);
    
    // Insert sample skills
    await db.insert(skills).values(sampleSkills);

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
seedDatabase()
  .then(() => {
    console.log("Seeding completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });